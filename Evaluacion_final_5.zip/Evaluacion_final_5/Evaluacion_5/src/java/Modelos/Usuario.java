/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Miguel
 */
public class Usuario {
    
    
int idusuario;
String nombre;
String apellido;
String fechanac;
int runusuario ;
String tipousuario;

    public Usuario() {
    }

    public Usuario(int idusuario, String nombre, String apellido, String fechanac, int runusuario, String tipousuario) {
        this.idusuario = idusuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechanac = fechanac;
        this.runusuario = runusuario;
        this.tipousuario = tipousuario;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getFechanac() {
        return fechanac;
    }

    public void setFechanac(String fechanac) {
        this.fechanac = fechanac;
    }

    public int getRunusuario() {
        return runusuario;
    }

    public void setRunusuario(int runusuario) {
        this.runusuario = runusuario;
    }

    public String getTipousuario() {
        return tipousuario;
    }

    public void setTipousuario(String tipousuario) {
        this.tipousuario = tipousuario;
    }



    
    
}
