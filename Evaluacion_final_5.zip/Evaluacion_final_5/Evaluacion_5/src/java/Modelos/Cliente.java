/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Miguel
 */
public class Cliente {
    
 int idcliente;  
 int rutcliente;
 String clirazonsocial;
  String clitelefono;
  String clidireccion;
  String clicomuna;
  int clicantempleados;

    public Cliente() {
    }

    public Cliente(int idcliente, int rutcliente, String clirazonsocial, String clitelefono, String clidireccion, String clicomuna, int clicantempleados) {
        this.idcliente = idcliente;
        this.rutcliente = rutcliente;
        this.clirazonsocial = clirazonsocial;
        this.clitelefono = clitelefono;
        this.clidireccion = clidireccion;
        this.clicomuna = clicomuna;
        this.clicantempleados = clicantempleados;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public int getRutcliente() {
        return rutcliente;
    }

    public void setRutcliente(int rutcliente) {
        this.rutcliente = rutcliente;
    }

    public String getClirazonsocial() {
        return clirazonsocial;
    }

    public void setClirazonsocial(String clirazonsocial) {
        this.clirazonsocial = clirazonsocial;
    }

    public String getClitelefono() {
        return clitelefono;
    }

    public void setClitelefono(String clitelefono) {
        this.clitelefono = clitelefono;
    }

    public String getClidireccion() {
        return clidireccion;
    }

    public void setClidireccion(String clidireccion) {
        this.clidireccion = clidireccion;
    }

    public String getClicomuna() {
        return clicomuna;
    }

    public void setClicomuna(String clicomuna) {
        this.clicomuna = clicomuna;
    }

    public int getClicantempleados() {
        return clicantempleados;
    }

    public void setClicantempleados(int clicantempleados) {
        this.clicantempleados = clicantempleados;
    }
    
    
  
  
  
}
