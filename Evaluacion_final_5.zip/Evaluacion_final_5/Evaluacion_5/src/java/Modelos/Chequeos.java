/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Miguel
 */
public class Chequeos {
    
     int idchequeo;	
     String nomchequeo;

    public Chequeos() {
    }

    public Chequeos(int idchequeo, String nomchequeo) {
        this.idchequeo = idchequeo;
        this.nomchequeo = nomchequeo;
    }

    public int getIdchequeo() {
        return idchequeo;
    }

    public void setIdchequeo(int idchequeo) {
        this.idchequeo = idchequeo;
    }

    public String getNomchequeo() {
        return nomchequeo;
    }

    public void setNomchequeo(String nomchequeo) {
        this.nomchequeo = nomchequeo;
    }
    
     
     
}
