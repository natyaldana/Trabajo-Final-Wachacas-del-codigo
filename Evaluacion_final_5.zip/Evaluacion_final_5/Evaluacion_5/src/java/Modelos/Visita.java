/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Miguel
 */
public class Visita {
    
     int idvisita;
 String visfecha;
 String vishora;
 String vislugar;
 String viscomentarios;
 int cliente_rutcliente;

    public Visita() {
    }

    public Visita(int idvisita, String visfecha, String vishora, String vislugar, String viscomentarios, int cliente_rutcliente) {
        this.idvisita = idvisita;
        this.visfecha = visfecha;
        this.vishora = vishora;
        this.vislugar = vislugar;
        this.viscomentarios = viscomentarios;
        this.cliente_rutcliente = cliente_rutcliente;
    }

    public int getIdvisita() {
        return idvisita;
    }

    public void setIdvisita(int idvisita) {
        this.idvisita = idvisita;
    }

    public String getVisfecha() {
        return visfecha;
    }

    public void setVisfecha(String visfecha) {
        this.visfecha = visfecha;
    }

    public String getVishora() {
        return vishora;
    }

    public void setVishora(String vishora) {
        this.vishora = vishora;
    }

    public String getVislugar() {
        return vislugar;
    }

    public void setVislugar(String vislugar) {
        this.vislugar = vislugar;
    }

    public String getViscomentarios() {
        return viscomentarios;
    }

    public void setViscomentarios(String viscomentarios) {
        this.viscomentarios = viscomentarios;
    }

    public int getCliente_rutcliente() {
        return cliente_rutcliente;
    }

    public void setCliente_rutcliente(int cliente_rutcliente) {
        this.cliente_rutcliente = cliente_rutcliente;
    }
    
 
 
 
 
    
}
