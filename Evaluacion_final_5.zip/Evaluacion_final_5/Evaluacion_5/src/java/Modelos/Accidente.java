/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Miguel
 */
public class Accidente {
    
 int idaccidente;	
 String accifecha;	
  String accihora ;	
  String accilugar ;	
  String acciorigen ;	
  String acciconsecuencias ;	
 int cliente_rutcliente;

    public Accidente() {
    }

    public Accidente(int idaccidente, String accifecha, String accihora, String accilugar, String acciorigen, String acciconsecuencias, int cliente_rutcliente) {
        this.idaccidente = idaccidente;
        this.accifecha = accifecha;
        this.accihora = accihora;
        this.accilugar = accilugar;
        this.acciorigen = acciorigen;
        this.acciconsecuencias = acciconsecuencias;
        this.cliente_rutcliente = cliente_rutcliente;
    }

    public int getIdaccidente() {
        return idaccidente;
    }

    public void setIdaccidente(int idaccidente) {
        this.idaccidente = idaccidente;
    }

    public String getAccifecha() {
        return accifecha;
    }

    public void setAccifecha(String accifecha) {
        this.accifecha = accifecha;
    }

    public String getAccihora() {
        return accihora;
    }

    public void setAccihora(String accihora) {
        this.accihora = accihora;
    }

    public String getAccilugar() {
        return accilugar;
    }

    public void setAccilugar(String accilugar) {
        this.accilugar = accilugar;
    }

    public String getAcciorigen() {
        return acciorigen;
    }

    public void setAcciorigen(String acciorigen) {
        this.acciorigen = acciorigen;
    }

    public String getAcciconsecuencias() {
        return acciconsecuencias;
    }

    public void setAcciconsecuencias(String acciconsecuencias) {
        this.acciconsecuencias = acciconsecuencias;
    }

    public int getCliente_rutcliente() {
        return cliente_rutcliente;
    }

    public void setCliente_rutcliente(int cliente_rutcliente) {
        this.cliente_rutcliente = cliente_rutcliente;
    }
    
    
    
}
