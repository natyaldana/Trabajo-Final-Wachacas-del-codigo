
package Controler;

import Config.Conexion;
import Modelos.Capacitacion;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorCapacitacion {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarCapacitacion.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from capacitacion";
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarCapacitacion");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarCapacitacion.htm", method = RequestMethod.GET)// AgregarCapacitacion.htm =>> AgregarVisita.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Capacitacion());
    mav.setViewName("AgregarCapacitacion");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarCapacitacion.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Capacitacion c){
    
   String sql="INSERT INTO capacitacion (idcapacitacion,capfecha,caphora,caplugar,capduracion,cliente_rutcliente) VALUES (?,?,?,?,?,?)";
    this.jdbctemplate.update(sql,c.getIdcapacitacion(),c.getCapfecha(),c.getCaphora(),c.getCaplugar(),c.getCapduracion(),c.getCliente_rutcliente());
     return new ModelAndView("redirect:/ListarCapacitacion.htm");//redirect:/ListarVisita.htm
    }
    
    
    @RequestMapping(value= "EditarCapacitacion.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from capacitacion where idcapacitacion="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarCapacitacion");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarCapacitacion.htm", method = RequestMethod.POST)
    public ModelAndView editar(Capacitacion c){
    
    
    String sql="UPDATE capacitacion SET capfecha=?,caphora=?,caplugar=?,capduracion=?,cliente_rutcliente=? WHERE idcapacitacion="+id; 
    this.jdbctemplate.update(sql,c.getIdcapacitacion(),c.getCapfecha(),c.getCaphora(),c.getCaplugar(),c.getCapduracion(),c.getCliente_rutcliente());
    mav.addObject("lista", datos);
    mav.setViewName("EditarCapacitacion");
    return new ModelAndView("redirect:/ListarCapacitacion.htm");
    
    
    }
    
    @RequestMapping("EliminarCapacitacion.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM capacitacion WHERE idcapacitacion="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarCapacitacion.htm");
    }
    
    
}
