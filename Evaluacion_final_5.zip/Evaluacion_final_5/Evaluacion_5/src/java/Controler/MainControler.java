/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Miguel
 */
public class MainControler {
    
    
   
    ModelAndView mav=new ModelAndView();
    
    
    
    
    @RequestMapping("index.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    mav.setViewName("index");
    return mav;
    
    }
    
    @RequestMapping("about.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar2(){
    mav.setViewName("about");
    return mav;
    
    }
    
     @RequestMapping("contact.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar3(){
    mav.setViewName("contact");
    return mav;
    
    }
    
    
    
}
