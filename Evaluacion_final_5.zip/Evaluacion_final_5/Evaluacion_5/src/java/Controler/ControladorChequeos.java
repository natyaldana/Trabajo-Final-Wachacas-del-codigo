
package Controler;

import Config.Conexion;
import Modelos.Chequeos;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorChequeos {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarChequeos.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from chequeos";
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarChequeos");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarChequeos.htm", method = RequestMethod.GET)// AgregarChequeos.htm =>> AgregarVisita.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Chequeos());
    mav.setViewName("AgregarChequeos");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarChequeos.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Chequeos c){
    
   String sql="INSERT INTO chequeos (idchequeo,nomchequeo) VALUES (?,?)";
    this.jdbctemplate.update(sql,c.getIdchequeo(),c.getNomchequeo());
     return new ModelAndView("redirect:/ListarChequeos.htm");//redirect:/ListarVisita.htm
    }
    
    
    @RequestMapping(value= "EditarChequeos.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from chequeos where idchequeo="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarChequeos");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarChequeos.htm", method = RequestMethod.POST)
    public ModelAndView editar(Chequeos c){
    
    
    String sql="UPDATE chequeos SET nomchequeo=? WHERE idchequeo="+id; 
    this.jdbctemplate.update(sql,c.getIdchequeo(),c.getNomchequeo());
    mav.addObject("lista", datos);
    mav.setViewName("EditarChequeos");
    return new ModelAndView("redirect:/ListarChequeos.htm");
    
    
    }
    
    @RequestMapping("EliminarChequeos.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM chequeos WHERE idchequeo="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarChequeos.htm");
    }
    
    
}
