package Controler;

import Config.Conexion;
import Modelos.Cliente;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorCliente {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarCliente.htm") // @RequestMapping("ListarCliente.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from cliente";
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarCliente");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarCliente.htm", method = RequestMethod.GET)// AgregarCliente.htm =>> AgregarCliente.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Cliente());
    mav.setViewName("AgregarCliente");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarCliente.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Cliente c){
    
   String sql="INSERT INTO cliente (idcliente,rutcliente,clirazonsocial,clitelefono,clidireccion,clicomuna,clicantempleados) VALUES (?,?,?,?,?,?,?)";
    this.jdbctemplate.update(sql,c.getIdcliente(),c.getRutcliente(),c.getClirazonsocial(),c.getClitelefono(),c.getClidireccion(),c.getClicomuna(),c.getClicantempleados());
     return new ModelAndView("redirect:/ListarCliente.htm");//redirect:/ListarCliente.htm
    }
    
    
    @RequestMapping(value= "EditarCliente.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from cliente where idcliente="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarCliente");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarCliente.htm", method = RequestMethod.POST)
    public ModelAndView editar(Cliente c){
    
    
    String sql="UPDATE cliente SET rutcliente=?,clirazonsocial=?,clitelefono=?,clidireccion=?,clicomuna=?,clicantempleados=? WHERE idcliente="+id; 
    this.jdbctemplate.update(sql,c.getIdcliente(),c.getRutcliente(),c.getClirazonsocial(),c.getClitelefono(),c.getClidireccion(),c.getClicomuna(),c.getClicantempleados());
    mav.addObject("lista", datos);
    mav.setViewName("EditarCliente");
    return new ModelAndView("redirect:/ListarCliente.htm");
    
    
    }
    
    @RequestMapping("EliminarCliente.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM cliente WHERE idcliente="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarCliente.htm");
    }
    
    
}
