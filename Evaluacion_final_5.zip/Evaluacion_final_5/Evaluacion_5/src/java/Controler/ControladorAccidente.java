package Controler;

import Config.Conexion;
import Modelos.Accidente;// modificar por el nombre de la tabla ejemplo: Modelos.Visita
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorAccidente {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarAccidente.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from accidente";// aca tambien modificar por nombre tabla
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarAccidente");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarAccidente.htm", method = RequestMethod.GET)// Agregaraccidente.htm =>> AgregarVisita.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Accidente());
    mav.setViewName("AgregarAccidente");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarAccidente.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Accidente a){
    
   String sql="INSERT INTO accidente (idaccidentes,accifecha,accihora,accilugar,acciorigen,acciconsecuencias,clientes_rutcliente) VALUES (?,?,?,?,?,?,?)";// ojo aqui
    this.jdbctemplate.update(sql,a.getIdaccidente(),a.getAccifecha(),a.getAccihora(),a.getAccilugar(),a.getAcciorigen(),a.getAcciconsecuencias(),a.getCliente_rutcliente());
     return new ModelAndView("redirect:/ListarAccidente.htm");//redirect:/ListarVisita.htm
    }
    
    
    @RequestMapping(value= "EditarAccidente.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from accidente where idaccidente="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarAccidente");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarAccidente.htm", method = RequestMethod.POST)
    public ModelAndView editar(Accidente a){
    
    
    String sql="UPDATE accidente SET idaccidente=?,accifecha=?,accihora=?,accilugar=?,acciorigen=?,acciconsecuencias=?,cliente_rutcliente=? WHERE idaccidente="+id; // ojo aqui
    this.jdbctemplate.update(sql,a.getIdaccidente(),a.getAccifecha(),a.getAccihora(),a.getAccilugar(),a.getAcciorigen(),a.getAcciconsecuencias(),a.getCliente_rutcliente());
    mav.addObject("lista", datos);
    mav.setViewName("EditarAccidente");
    return new ModelAndView("redirect:/ListarAccidente.htm");
    
    
    }
    
    @RequestMapping("EliminarAccidente.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM accidente WHERE idaccidente="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarAccidente.htm");
    }
    
    
}
