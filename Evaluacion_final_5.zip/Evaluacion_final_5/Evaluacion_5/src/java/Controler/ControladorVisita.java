
package Controler;

import Config.Conexion;
import Modelos.Visita;// modificar por el nombre de la tabla ejemplo: Modelos.Visita
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorVisita {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarVisita.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from visita";// aca tambien modificar por nombre tabla
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarVisita");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarVisita.htm", method = RequestMethod.GET)// AgregarUsuario.htm =>> AgregarVisita.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Visita());
    mav.setViewName("AgregarVisita");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarVisita.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Visita v){
    
   String sql="INSERT INTO Visita (idvisita,visfecha,vishora,vislugar,viscomentario,cliente_rutcliente) VALUES (?,?,?,?,?,?)";// ojo aqui
    this.jdbctemplate.update(sql,v.getIdvisita(),v.getVisfecha(),v.getVishora(),v.getVislugar(),v.getViscomentarios(),v.getCliente_rutcliente());
     return new ModelAndView("redirect:/ListarVisita.htm");//redirect:/ListarVisita.htm
    }
    
    
    @RequestMapping(value= "EditarVisita.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from visita where idvisita="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarVisita");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarVisita.htm", method = RequestMethod.POST)
    public ModelAndView editar(Visita v){
    
    
    String sql="UPDATE visita SET idvisita=?,visfecha=?,vishora=?,vislugar=?,viscomentario=?,cliente_rutcliente=? WHERE idvisita="+id; // ojo aqui
    this.jdbctemplate.update(sql,v.getIdvisita(),v.getVisfecha(),v.getVishora(),v.getVislugar(),v.getViscomentarios(),v.getCliente_rutcliente());
    mav.addObject("lista", datos);
    mav.setViewName("EditarVisita");
    return new ModelAndView("redirect:/ListarVisita.htm");
    
    
    }
    
    @RequestMapping("EliminarUsuario.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM visita WHERE idvisita="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarVisita.htm");
    }
    
    
}
