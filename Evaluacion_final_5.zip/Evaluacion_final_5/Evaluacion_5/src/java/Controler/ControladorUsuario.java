
package Controler;

import Config.Conexion;
import Modelos.Usuario;// modificar por el nombre de la tabla ejemplo: Modelos.Visita
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ControladorUsuario {
    
    Conexion con= new Conexion();
    JdbcTemplate jdbctemplate= new JdbcTemplate(con.conectar());
    ModelAndView mav=new ModelAndView();
    int id;
    List datos;
    
    
    @RequestMapping("ListarUsuario.htm") // @RequestMapping("ListarVisita.htm")
    public ModelAndView Listar(){
    String sql="SELECT * from usuario";// aca tambien modificar por nombre tabla
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("ListarUsuario");
    return mav;
    
    }
    

    @RequestMapping(value= "AgregarUsuario.htm", method = RequestMethod.GET)// AgregarUsuario.htm =>> AgregarVisita.htm
    public ModelAndView agregar(){
    
    mav.addObject(new Usuario());
    mav.setViewName("AgregarUsuario");
    return mav;
    
    
    }
    
    @RequestMapping(value= "AgregarUsuario.htm", method = RequestMethod.POST)
    public ModelAndView agregar(Usuario u){
    
   String sql="INSERT INTO usuario (idusuario,nombre,apellido,fechanac,runusuario,tipousuario) VALUES (?,?,?,?,?,?)";// ojo aqui
    this.jdbctemplate.update(sql,u.getIdusuario(),u.getNombre(),u.getApellido(),u.getFechanac(),u.getRunusuario(),u.getTipousuario());
     return new ModelAndView("redirect:/ListarUsuario.htm");//redirect:/ListarVisita.htm
    }
    
    
    @RequestMapping(value= "EditarUsuario.htm", method = RequestMethod.GET)
    public ModelAndView editar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="SELECT * from usuario where idusuario="+id;
    datos=this.jdbctemplate.queryForList(sql);
    mav.addObject("lista", datos);
    mav.setViewName("EditarUsuario");
    return mav;
    
    
    }
    
    
    
    @RequestMapping(value= "EditarUsuario.htm", method = RequestMethod.POST)
    public ModelAndView editar(Usuario u){
    
    
    String sql="UPDATE usuario SET nombre=?,apellido=?,fechanac=?,runusuario=?,tipousuario=? WHERE idusuario="+id; // ojo aqui
    this.jdbctemplate.update(sql,u.getNombre(),u.getApellido(),u.getFechanac(),u.getRunusuario(),u.getTipousuario());
    mav.addObject("lista", datos);
    mav.setViewName("EditarUsuario");
    return new ModelAndView("redirect:/ListarUsuario.htm");
    
    
    }
    
    @RequestMapping("EliminarUsuario.htm")
    public ModelAndView eliminar(HttpServletRequest request){
    
    id=Integer.parseInt(request.getParameter("id"));
    String sql="DELETE FROM usuario WHERE idusuario="+id;
    
    this.jdbctemplate.update(sql);
    return new ModelAndView("redirect:/ListarUsuario.htm");
    }
    
    
}
