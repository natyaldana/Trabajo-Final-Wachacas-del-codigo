# Landing de programa de los Wachacas.

- Desarrollado por los Wachacas del código, 2021
- Diseño Natalia Aldana.
- Desarrollo: Felipe morales.


## Liderazgo Colaborativo Digital
Landing del programa para la gestión de datos de una organización concerniente a la administración en prevención de riesgo.

## Herramientas Digitales en el Aula
Landing del programa para la gestión de datos aplicada a la prevención de riesgos.

## Planificación de una clase virtual
Gestiona de manera simple, datos para la administración de la prevención de riesgos en una organización.

## Tecnologías
- HTML5
- JAVA
- CSS
- SQL
- GITHUB    natyaldana/Evaluacion-Final-
