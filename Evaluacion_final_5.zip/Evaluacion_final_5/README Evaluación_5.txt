# EvaluacionFinal5
MVC, Servlet, JSP, Tomcat, EclipseId, Style, Bootstrap, SQL, Spring ToolSuite 4, Maven, JDBC Template
Rest API, Sprinh Security, JPA.

# Landing de programa de los Wachacas.

- Desarrollado por los Wachacas del código, 2021
- Diseño Natalia Aldana y Cristian Urra.
- Desarrollo: Felipe morales y Nelson Flores.


## Liderazgo Colaborativo Digital
Landing del programa para la gestión de datos de una organización concerniente a la administración en prevención de riesgo,
desarrollo de solución a la gestión tecnológica, enfocada a distintos tipos y perfiles de usuarios.

## Herramientas Digitales en el proyecto
Landing del programa para la gestión de datos aplicada a la prevención de riesgos.

## Planificación de una clase virtual
Gestiona de manera simple, datos para la administración de la prevención de riesgos en una organización.
Simplifica procesos administrativos para simplificar y reducir costos ineficientes por falta de herramientas TI.

## Tecnologías
- HTML5
- JAVA
- CSS
- SQL
- Servlet
- Bootstrap
- MVC
- Tomcat Apache
- JSP
- Spring ToolSuite 4
- Maven
- JDBC Template
- API Rest
- Eclipse ID
- Spring Security

## Rutas repositorios GITHUB
- https://github.com/cristiantrader
- https://github.com/moralesfelipe



Proyecto desarrollado por Wachacas S.A. orientado a la solución de problemas de gestión al Core Bussines de empresas.