-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 14-09-2021 a las 23:07:22
-- Versión del servidor: 5.7.17-log
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `asesorias_prevencion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accidente`
--

CREATE TABLE `accidente` (
  `idaccidente` int(9) NOT NULL,
  `accifecha` date NOT NULL,
  `accihora` date NOT NULL,
  `accilugar` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `acciorigen` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `acciconsecuencias` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `cliente_rutcliente` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `accidente`
--

INSERT INTO `accidente` (`idaccidente`, `accifecha`, `accihora`, `accilugar`, `acciorigen`, `acciconsecuencias`, `cliente_rutcliente`) VALUES
(1, '2021-09-19', '2020-12-19', 'oficina', 'se cayo', 'se murio', 3453453),
(2, '2021-06-30', '2020-05-28', 'su casa', 'se quemo', 'quemadura segundo grado', 358855),
(3, '2021-12-12', '2020-11-20', 'terreno', 'golpeado por', 'contusion', 7654356);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admnistrativo`
--

CREATE TABLE `admnistrativo` (
  `idadministrativo` int(9) NOT NULL,
  `admnombres` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `admapellidos` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `admnombresup` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `admarea` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `admexpprevia` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `admfuncion` varchar(20) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `admnistrativo`
--

INSERT INTO `admnistrativo` (`idadministrativo`, `admnombres`, `admapellidos`, `admnombresup`, `admarea`, `admexpprevia`, `admfuncion`) VALUES
(1, 'jose maria', 'cortez silva', 'Jose viñuela', 'Contabilidad', 'participó en proyectois similares', 'control interno'),
(2, 'xavi alonso', 'hernadez dias', 'joaquin bello', 'finanzas', 'ha realizado ratios financieros para estudio de mercado', 'estudio de mercado'),
(3, 'paola cecilia', 'becerra olivares', 'miguel nuñez', 'produccion', 'proceso de elaboracion de productos', 'calculo inventarios');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asesorias`
--

CREATE TABLE `asesorias` (
  `idasesoria` int(9) NOT NULL,
  `asefecha` date NOT NULL,
  `asemotivo` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `asesoria_idprofesional` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `asesorias`
--

INSERT INTO `asesorias` (`idasesoria`, `asefecha`, `asemotivo`, `asesoria_idprofesional`) VALUES
(1, '2021-10-09', 'Capacitación uso de herramientas computacionales', 1),
(2, '2021-12-18', 'Capacitación medidas de prevención de riesgo', 2),
(3, '2021-05-17', 'Capacitación en medidas de reanimacion', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistentes`
--

CREATE TABLE `asistentes` (
  `idasistente` int(9) NOT NULL,
  `asistnombrecompleto` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `asistedad` int(3) NOT NULL,
  `asistcorreo` varchar(70) COLLATE latin1_spanish_ci DEFAULT NULL,
  `asisttelefono` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `capacitacion_idcapacitacion` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `asistentes`
--

INSERT INTO `asistentes` (`idasistente`, `asistnombrecompleto`, `asistedad`, `asistcorreo`, `asisttelefono`, `capacitacion_idcapacitacion`) VALUES
(1, 'Ines Saavedra', 26, 'ines@gmail.com', '963856952', 1),
(2, 'Victor Mendez', 33, 'victor.mendez@gmail.com', '936852693', 2),
(3, 'Eduardo Diaz', 40, 'edu@gmail.com', '956963251', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `capacitacion`
--

CREATE TABLE `capacitacion` (
  `idcapacitacion` int(9) NOT NULL,
  `capfecha` date NOT NULL,
  `caphora` date DEFAULT NULL,
  `caplugar` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `capduracion` int(4) DEFAULT NULL,
  `cliente_rutcliente` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `capacitacion`
--

INSERT INTO `capacitacion` (`idcapacitacion`, `capfecha`, `caphora`, `caplugar`, `capduracion`, `cliente_rutcliente`) VALUES
(1, '2021-06-14', '2021-06-14', 'centro cultural', 100, 19369852),
(2, '2021-09-30', '2021-09-30', 'hotel piedradura', 180, 7963462),
(3, '2021-11-04', '2021-11-04', 'centro de eventos las acacias', 50, 12396523);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chequeos`
--

CREATE TABLE `chequeos` (
  `idchequeo` int(9) NOT NULL,
  `nomchequeo` varchar(50) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `chequeos`
--

INSERT INTO `chequeos` (`idchequeo`, `nomchequeo`) VALUES
(1, 'INSPECCION EN TERRENO 1'),
(2, ' INSPECCION EN TERRENO 2'),
(3, ' INSPECCION EN TERRENO 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `idcliente` int(9) NOT NULL,
  `rutcliente` int(9) DEFAULT NULL,
  `clirazonsocial` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `clitelefono` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `clidireccion` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `clicomuna` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `clicantempleados` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`idcliente`, `rutcliente`, `clirazonsocial`, `clitelefono`, `clidireccion`, `clicomuna`, `clicantempleados`) VALUES
(1, 73405354, 'Consultores Civiles', '28311709', 'camino el bajo 22', 'Alhue', 25),
(2, 82819625, 'Manetti', '8503456', 'libertad 133', 'Chimbarongo', 40),
(3, 65353889, 'Montserrat', '45660448', 'las lilas 298', 'Talcahuano', 37),
(4, 73233567, 'Acyys Auditores', '96678445', 'chinchille 2352', 'estacion central', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mejoras`
--

CREATE TABLE `mejoras` (
  `idmejoras` int(9) NOT NULL,
  `mejtitulo` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `mejdescripcion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `mejplazo` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `mejoras`
--

INSERT INTO `mejoras` (`idmejoras`, `mejtitulo`, `mejdescripcion`, `mejplazo`) VALUES
(1, 'implementar seg', 'poner en todas las ventanas de la oficina', 18),
(2, 'insertar señ', 'pegar señaleticas en todos los pasillos', 10),
(3, 'compra de vest', 'se debe proporcionar a los trabajadores equipamiento en vestuario adecuado cada 3 meses', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagocliente`
--

CREATE TABLE `pagocliente` (
  `idcliente` int(9) NOT NULL,
  `idpago` int(5) DEFAULT NULL,
  `fechapago` date NOT NULL,
  `montopago` int(10) NOT NULL,
  `mes` date NOT NULL,
  `años` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `pagocliente`
--

INSERT INTO `pagocliente` (`idcliente`, `idpago`, `fechapago`, `montopago`, `mes`, `años`) VALUES
(1, 1, '2021-08-15', 104500, '2021-08-15', '2021-08-15'),
(2, 2, '2021-04-15', 355500, '2021-04-15', '2021-04-15'),
(3, 3, '2021-01-28', 60850, '2021-01-28', '2021-01-28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesional`
--

CREATE TABLE `profesional` (
  `idprofesional` int(9) NOT NULL,
  `profnombres` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `profapellidos` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `proftitulo` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  `departamento` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `añosexperiencia` int(2) DEFAULT NULL,
  `fechaingreso` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `profesional`
--

INSERT INTO `profesional` (`idprofesional`, `profnombres`, `profapellidos`, `proftitulo`, `departamento`, `añosexperiencia`, `fechaingreso`) VALUES
(1, 'Jose Benito', 'Bello Hermoso', 'Auditor', 'Contabilidad', 3, '2019-01-21'),
(2, 'Rosa Maria', 'Espinoza Sanchez', 'prevencionista', 'logistica', 6, '2015-01-21'),
(3, 'Jose Jose', 'Rojas Urrutia', 'ingeniero', 'operaciones', 8, '2013-01-21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registrochequeo`
--

CREATE TABLE `registrochequeo` (
  `idregistrochequeo` int(9) NOT NULL,
  `cumplimiento` char(1) COLLATE latin1_spanish_ci NOT NULL,
  `observaciones` varchar(250) COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `registrochequeo`
--

INSERT INTO `registrochequeo` (`idregistrochequeo`, `cumplimiento`, `observaciones`) VALUES
(1, 'N', 'Debi planificar mejor mi trabajo'),
(2, 'S', 'Realicé un trabajo satisfactorio'),
(3, 'N', 'Tuve problemas familiares lo que imposibilitó mi desempeño optimo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(9) NOT NULL,
  `nombre` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `apellido` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `fechanac` date NOT NULL,
  `runusuario` int(10) NOT NULL,
  `tipousuario` varchar(20) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombre`, `apellido`, `fechanac`, `runusuario`, `tipousuario`) VALUES
(1, 'buena nati', 'Aldana', '1986-01-21', 16291146, 'administrativo'),
(2, 'Cristian', 'Urra', '1988-08-31', 17028504, 'profesional'),
(3, 'Felipe', 'Morales', '1982-03-13', 15430618, 'cliente'),
(4, 'Nelson', 'Flores', '0198-01-21', 16291146, 'administrativo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita`
--

CREATE TABLE `visita` (
  `idvisita` int(9) NOT NULL,
  `visfecha` date NOT NULL,
  `vishora` date DEFAULT NULL,
  `vislugar` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `viscomentarios` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `cliente_rutcliente` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `visita`
--

INSERT INTO `visita` (`idvisita`, `visfecha`, `vishora`, `vislugar`, `viscomentarios`, `cliente_rutcliente`) VALUES
(1, '2021-06-21', '2021-06-21', 'casino', 'fue derivado a la posta central', 6389617),
(2, '2021-03-02', '2021-03-02', 'salareunion', 'se le hizo curaciones menores', 9673696),
(3, '2021-06-13', '2021-06-13', 'oficina', 'se produjo un sangramiento intenso', 2547412);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accidente`
--
ALTER TABLE `accidente`
  ADD PRIMARY KEY (`idaccidente`);

--
-- Indices de la tabla `admnistrativo`
--
ALTER TABLE `admnistrativo`
  ADD PRIMARY KEY (`idadministrativo`);

--
-- Indices de la tabla `asesorias`
--
ALTER TABLE `asesorias`
  ADD PRIMARY KEY (`idasesoria`),
  ADD KEY `fk_asesoria_idprofesional2` (`asesoria_idprofesional`);

--
-- Indices de la tabla `asistentes`
--
ALTER TABLE `asistentes`
  ADD PRIMARY KEY (`idasistente`),
  ADD KEY `fk_capacitacion_idcapacitacion1` (`capacitacion_idcapacitacion`);

--
-- Indices de la tabla `capacitacion`
--
ALTER TABLE `capacitacion`
  ADD PRIMARY KEY (`idcapacitacion`);

--
-- Indices de la tabla `chequeos`
--
ALTER TABLE `chequeos`
  ADD PRIMARY KEY (`idchequeo`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idcliente`);

--
-- Indices de la tabla `mejoras`
--
ALTER TABLE `mejoras`
  ADD PRIMARY KEY (`idmejoras`);

--
-- Indices de la tabla `pagocliente`
--
ALTER TABLE `pagocliente`
  ADD PRIMARY KEY (`idcliente`);

--
-- Indices de la tabla `profesional`
--
ALTER TABLE `profesional`
  ADD PRIMARY KEY (`idprofesional`);

--
-- Indices de la tabla `registrochequeo`
--
ALTER TABLE `registrochequeo`
  ADD PRIMARY KEY (`idregistrochequeo`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`);

--
-- Indices de la tabla `visita`
--
ALTER TABLE `visita`
  ADD PRIMARY KEY (`idvisita`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `accidente`
--
ALTER TABLE `accidente`
  ADD CONSTRAINT `fk_idaccidente1` FOREIGN KEY (`idaccidente`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `admnistrativo`
--
ALTER TABLE `admnistrativo`
  ADD CONSTRAINT `fk_idadministrativo1` FOREIGN KEY (`idadministrativo`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asesorias`
--
ALTER TABLE `asesorias`
  ADD CONSTRAINT `fk_asesoria_idprofesional2` FOREIGN KEY (`asesoria_idprofesional`) REFERENCES `profesional` (`idprofesional`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asistentes`
--
ALTER TABLE `asistentes`
  ADD CONSTRAINT `fk_capacitacion_idcapacitacion1` FOREIGN KEY (`capacitacion_idcapacitacion`) REFERENCES `capacitacion` (`idcapacitacion`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `capacitacion`
--
ALTER TABLE `capacitacion`
  ADD CONSTRAINT `fk_idcapacitacion1` FOREIGN KEY (`idcapacitacion`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `chequeos`
--
ALTER TABLE `chequeos`
  ADD CONSTRAINT `fk_idchequeo1` FOREIGN KEY (`idchequeo`) REFERENCES `visita` (`idvisita`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `fk_idcliente1` FOREIGN KEY (`idcliente`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `mejoras`
--
ALTER TABLE `mejoras`
  ADD CONSTRAINT `fk_idmejoras2` FOREIGN KEY (`idmejoras`) REFERENCES `asesorias` (`idasesoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pagocliente`
--
ALTER TABLE `pagocliente`
  ADD CONSTRAINT `fk_idcliente2` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `profesional`
--
ALTER TABLE `profesional`
  ADD CONSTRAINT `fk_idprofesional1` FOREIGN KEY (`idprofesional`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `registrochequeo`
--
ALTER TABLE `registrochequeo`
  ADD CONSTRAINT `fk_idregistrochequeo1` FOREIGN KEY (`idregistrochequeo`) REFERENCES `chequeos` (`idchequeo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `visita`
--
ALTER TABLE `visita`
  ADD CONSTRAINT `fk_idvisita1` FOREIGN KEY (`idvisita`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
